package com.example.lms.model;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "payment_table")
@SequenceGenerator(name = "payment", sequenceName = "payment_gen", initialValue=6000)
public class Payment {
	
	@Id
	@Column(name = "payment_id")
	@GeneratedValue( strategy = GenerationType.SEQUENCE , generator="payment")
	private long paymentId;
	
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "course_id")
	@JsonIgnore
	@OnDelete(action = OnDeleteAction.CASCADE)
	public Courses course;
	
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "student_id")
	@JsonIgnore
	@OnDelete(action = OnDeleteAction.CASCADE)
	public Student student;
	
	@Column(name = "course_price")
	public double coursePrice;
	
	@Column(name = "payment_status")
	public String paymentStatus;
	
	@Column(name = "payment_date")
	public String paymentDate;
	
	public Payment() {
		
	}

	public Payment(Courses course, Student student, double coursePrice, String paymentStatus, String paymentDate) {
		super();
		this.course = course;
		this.student = student;
		this.coursePrice = coursePrice;
		this.paymentStatus = paymentStatus;
		this.paymentDate = paymentDate;
	}

	public long getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(long paymentId) {
		this.paymentId = paymentId;
	}

	public Courses getCourse() {
		return course;
	}

	public void setCourse(Courses course) {
		this.course = course;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public double getCoursePrice() {
		return coursePrice;
	}

	public void setCoursePrice(double coursePrice) {
		this.coursePrice = coursePrice;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	@Override
	public String toString() {
		return "Payment [payment_id=" + paymentId + ", course=" + course + ", student=" + student + ", coursePrice="
				+ coursePrice + ", paymentStatus=" + paymentStatus + ", paymentDate=" + paymentDate + "]";
	}	
	
	

}
