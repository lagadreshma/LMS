package com.example.lms.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.lms.model.Student;
import com.example.lms.repository.StudentRepository;
import com.example.lms.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentRepository studentRepository;

    @Override
    public Student saveStudent(Student student) {
        return studentRepository.save(student);
    }

    @Override
    public Student loginStudent(Student student) {
        Optional<Student> studentOptional = studentRepository.findByStudentEmailAndStudentPassword(student.getStudentEmail(), student.getStudentPassword());
        return studentOptional.orElse(null); // Adjust error handling as needed
    }

    @Override
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    @Override
    public Student getStudentById(Student student, Long studentId) {
        return studentRepository.findById(studentId).orElse(null); // Adjust error handling as needed
    }

    @Override
    public void deleteStudent(Student student, Long studentId) {
        studentRepository.deleteById(studentId);
    }

    @Override
    public Student updateStudent(Student student, Long studentId) {
        Optional<Student> optionalExistingStudent = studentRepository.findById(studentId);
        if (optionalExistingStudent.isPresent()) {
            Student existingStudent = optionalExistingStudent.get();
            existingStudent.setStudentName(student.getStudentName());
            existingStudent.setStudentAge(student.getStudentAge());
            existingStudent.setStudentEmail(student.getStudentEmail());
            existingStudent.setStudentPassword(student.getStudentPassword());
            existingStudent.setStudentMobile(student.getStudentMobile());
            existingStudent.setStudentAddress(student.getStudentAddress());
            return studentRepository.save(existingStudent);
        } else {
            return null; // or throw exception as per your application's requirement
        }
    }
}
