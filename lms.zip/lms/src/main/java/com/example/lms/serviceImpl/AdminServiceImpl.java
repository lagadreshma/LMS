package com.example.lms.serviceImpl;

import java.util.NoSuchElementException;

import org.springframework.stereotype.Service;
import com.example.lms.model.Admin;
import com.example.lms.repository.AdminRepository;
import com.example.lms.service.AdminService;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AdminServiceImpl implements AdminService {

    private AdminRepository adminRepository;

    @Override
    public Admin loginAdmin(Admin admin) {
        String email = admin.getAdminEmail();
        String password = admin.getAdminPassword();
        
        return adminRepository.findByAdminEmailAndAdminPassword(email, password)
                .orElseThrow(() -> new RuntimeException("Admin not found with email: " + email));
    }

    @Override
    public Admin getAdminById(long adminId) {
        return adminRepository.findById(adminId)
                .orElseThrow(() -> new NoSuchElementException("Admin not found with id: " + adminId));
    }
}
