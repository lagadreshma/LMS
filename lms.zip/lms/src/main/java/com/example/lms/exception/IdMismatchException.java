package com.example.lms.exception;

public class IdMismatchException extends RuntimeException {
	
	public IdMismatchException(String msg) {
		super(msg);
	}

}
