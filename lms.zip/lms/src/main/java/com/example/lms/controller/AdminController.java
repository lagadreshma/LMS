package com.example.lms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.lms.model.Admin;
import com.example.lms.model.Student;
import com.example.lms.model.Trainer;
import com.example.lms.service.AdminService;
import com.example.lms.service.StudentService;
import com.example.lms.service.TrainerService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/lms_admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @Autowired
    private StudentService studentService;

    @Autowired
    private TrainerService trainerService;

    @PostMapping("/login")
    public ResponseEntity<Admin> loginAdmin(@RequestBody Admin admin) {
        return new ResponseEntity<>(adminService.loginAdmin(admin), HttpStatus.OK);
    }

    @GetMapping("/admins/{adminId}")
    public ResponseEntity<Admin> getAdminById(@PathVariable("adminId") long adminId) {
        return new ResponseEntity<>(adminService.getAdminById(adminId), HttpStatus.OK);
    }
    
    
    
    
}
