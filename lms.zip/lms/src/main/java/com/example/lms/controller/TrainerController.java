package com.example.lms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.lms.model.Trainer;
import com.example.lms.service.TrainerService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/lms_trainer/")
public class TrainerController {
	
	@Autowired
	public TrainerService trainerService;
	
	@PostMapping("/registerTrainer")
    public ResponseEntity<Trainer> saveTrainer(@RequestBody Trainer trainer) {
        System.out.println("Trainer Registration Successful." + trainer);
        return new ResponseEntity<>(trainerService.saveTrainer(trainer), HttpStatus.CREATED);
    }

    @GetMapping("/trainers")
    public List<Trainer> getAllTrainers() {
        return trainerService.getAllTrainer();
    }

    @GetMapping("/trainers/{trainerId}")
    public ResponseEntity<Trainer> getTrainerById(@PathVariable("trainerId") long trainerId, @RequestBody Trainer trainer) {
        return new ResponseEntity<>(trainerService.getTrainerById(trainer, trainerId), HttpStatus.OK);
    }

    @PutMapping("/trainers/{trainerId}")
    public ResponseEntity<Trainer> updateTrainer(@PathVariable("trainerId") long trainerId, @RequestBody Trainer trainer) {
        return new ResponseEntity<>(trainerService.updateTrainer(trainer, trainerId), HttpStatus.OK);
    }

    @DeleteMapping("/trainers/{trainerId}")
    public ResponseEntity<Boolean> deleteTrainer(@PathVariable("trainerId") long trainerId, @RequestBody Trainer trainer) {
        trainerService.deleteTrainer(trainer, trainerId);
        return new ResponseEntity<>(true, HttpStatus.OK);
    }

}
