package com.example.lms.serviceImpl;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.lms.model.Courses;
import com.example.lms.repository.CourseRepository;
import com.example.lms.service.CourseService;

@Service
public class CourseServiceImpl implements CourseService {

    @Autowired
    public CourseRepository courseRepository;

    @Override
    public Courses addCourse(Courses course) {
        return courseRepository.save(course);
    }

    @Override
    public List<Courses> getAllCourses() {
        return courseRepository.findAll();
    }

    @Override
    public Courses getCourseById(long courseId) {
        return courseRepository.findById(courseId)
                .orElseThrow(() -> new NoSuchElementException("Course not found with id: " + courseId));
    }

    @Override
    public boolean deleteCourseById(long courseId) {
        courseRepository.findById(courseId).orElseThrow(() -> new NoSuchElementException("Course not found with id: " + courseId));
        courseRepository.deleteById(courseId);
        return true;
    }

    @Override
    public Courses updateCourse(Courses course, long courseId) {
        Courses existingCourse = courseRepository.findById(courseId)
                .orElseThrow(() -> new NoSuchElementException("Course not found with id: " + courseId));

        existingCourse.setCourseName(course.getCourseName());
        existingCourse.setCourseDescription(course.getCourseDescription());
        existingCourse.setTrainerName(course.getTrainerName());
        existingCourse.setCoursePrice(course.getCoursePrice());
        
        // Only update the image if it is not null
        if (course.getCourseImage() != null) {
            existingCourse.setCourseImage(course.getCourseImage());
        }
        
        existingCourse.setCourseRating(course.getCourseRating());

        courseRepository.save(existingCourse);

        return existingCourse;
    }
}
