package com.example.lms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.lms.exception.CourseNotValidException;
import com.example.lms.model.Courses;
import com.example.lms.service.CourseService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/lms_courses/")
public class CourseController {
	
	@Autowired
	private CourseService courseService;
	
	@PostMapping("/addCourse")
	public ResponseEntity<Courses> addCourse(@PathVariable("adminId") long adminId, @RequestBody Courses course) throws CourseNotValidException{
		System.out.println("Course Added Succesfull "+ course);
		return new ResponseEntity<Courses>(courseService.addCourse(course),HttpStatus.CREATED);
	}
	
	@GetMapping("/courses")
	public List<Courses> getAllCourses(){
		return courseService.getAllCourses();
	}
	
	@GetMapping("/courses/{courseId}")
	public ResponseEntity<Courses> getCourseById(@PathVariable("courseId") long courseId){
		
		return new ResponseEntity<Courses>(courseService.getCourseById(courseId), HttpStatus.OK);
	}
	
	  // Endpoint to delete appointment by ID
    @DeleteMapping("/courses/{courseId}")
    public ResponseEntity<String> deleteCourseById(@PathVariable("courseId") long courseId) {
        if (courseService.deleteCourseById(courseId)) {
            return new ResponseEntity<>("Course deleted successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Course not found or unable to delete", HttpStatus.NOT_FOUND);
        }
    }
	
}

