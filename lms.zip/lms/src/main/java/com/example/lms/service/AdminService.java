package com.example.lms.service;

import com.example.lms.model.Admin;
import java.util.List;

public interface AdminService {
	
    Admin loginAdmin(Admin admin);
    
    Admin getAdminById(long adminId);
    
}


