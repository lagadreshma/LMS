package com.example.lms.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.lms.model.CourseContent;
import com.example.lms.repository.CourseContentRepository;
import com.example.lms.service.CourseContentService;

@Service
public class CourseContentServiceImpl implements CourseContentService {
	
	@Autowired
	public CourseContentRepository courseContentRepository;

	@Override
	public CourseContent addCourseContent(CourseContent courseContent) {
		// TODO Auto-generated method stub
		return courseContentRepository.save(courseContent);
	}

	@Override
	public List<CourseContent> getAllCourseContent() {
		// TODO Auto-generated method stub
		return courseContentRepository.findAll();
	}

	@Override
	public CourseContent getCourseContentById(long courseContentId) {
		// TODO Auto-generated method stub
		return courseContentRepository.findById(courseContentId).orElseThrow();
		
	}

	@Override
	public boolean deleteCourseContentById(long courseContentId) {
		// TODO Auto-generated method stub
		courseContentRepository.findById(courseContentId).orElseThrow();
		courseContentRepository.deleteById(courseContentId);
		return true;
	}

	@Override
	public CourseContent updateCourseContent(CourseContent courseContent, long courseContentId) {
		// TODO Auto-generated method stub
		
		CourseContent existingCourseContent = courseContentRepository.findById(courseContentId).orElseThrow();
		
		existingCourseContent.setContentName(courseContent.getContentName());
		existingCourseContent.setContentDescription(courseContent.getContentDescription());
		existingCourseContent.setCourseVideos(courseContent.getCourseVideos());
		
		courseContentRepository.save(existingCourseContent);
		
		
		return existingCourseContent;
	}

}
