package com.example.lms.service;

import com.example.lms.model.Courses;
import java.util.List;

public interface CourseService {
    Courses addCourse(Courses course);
    List<Courses> getAllCourses();
    Courses getCourseById(long courseId);
    boolean deleteCourseById(long courseId);
    Courses updateCourse(Courses course, long courseId);
}
