package com.example.lms.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "trainer_table")
@SequenceGenerator(name="trainer", sequenceName = "trainer_gen", initialValue=3000)
public class Trainer {

    @Id
    @Column(name = "trainer_id")
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="trainer")
    private long trainerId;

    @Column(name = "trainer_name")
    private String trainerName;

    @Column(name = "trainer_email")
    private String trainerEmail;

    @Column(name = "trainer_password")
    private String trainerPassword;

    @Column(name = "trainer_mobile")
    private String trainerMobile;

    @Column(name = "trainer_address")
    private String trainerAddress;

    public Trainer() {}

    public Trainer(String trainerName, String trainerEmail, String trainerPassword, String trainerMobile,
                   String trainerAddress) {
        super();
        this.trainerName = trainerName;
        this.trainerEmail = trainerEmail;
        this.trainerPassword = trainerPassword;
        this.trainerMobile = trainerMobile;
        this.trainerAddress = trainerAddress;
    }

    public long getTrainerId() {
        return trainerId;
    }

    public void setTrainerId(long trainerId) {
        this.trainerId = trainerId;
    }

    public String getTrainerName() {
        return trainerName;
    }

    public void setTrainerName(String trainerName) {
        this.trainerName = trainerName;
    }

    public String getTrainerEmail() {
        return trainerEmail;
    }

    public void setTrainerEmail(String trainerEmail) {
        this.trainerEmail = trainerEmail;
    }

    public String getTrainerPassword() {
        return trainerPassword;
    }

    public void setTrainerPassword(String trainerPassword) {
        this.trainerPassword = trainerPassword;
    }

    public String getTrainerMobile() {
        return trainerMobile;
    }

    public void setTrainerMobile(String trainerMobile) {
        this.trainerMobile = trainerMobile;
    }

    public String getTrainerAddress() {
        return trainerAddress;
    }

    public void setTrainerAddress(String trainerAddress) {
        this.trainerAddress = trainerAddress;
    }

    @Override
    public String toString() {
        return "Trainer [trainerId=" + trainerId + ", trainerName=" + trainerName + ", trainerEmail=" + trainerEmail
                + ", trainerPassword=" + trainerPassword + ", trainerMobile=" + trainerMobile + ", trainerAddress="
                + trainerAddress + "]";
    }
}
