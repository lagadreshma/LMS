package com.example.lms.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "course_content_table")
@Data
@NoArgsConstructor
@AllArgsConstructor
@SequenceGenerator(name = "course_content", sequenceName = "course_content_gen", initialValue = 5000)
public class CourseContent {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "course_content")
    @Column(name = "course_content_id")
    private Long contentId;

    @Column(name = "course_content_name")
    private String contentName;

    @Column(name = "course_content_desc")
    private String contentDescription;

    @Column(name = "course_videos")
    private String courseVideos;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "course_id")
    private Courses course;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "trainer_id")
    private Trainer trainer;

	public Long getContentId() {
		return contentId;
	}

	public void setContentId(Long contentId) {
		this.contentId = contentId;
	}

	public String getContentName() {
		return contentName;
	}

	public void setContentName(String contentName) {
		this.contentName = contentName;
	}

	public String getContentDescription() {
		return contentDescription;
	}

	public void setContentDescription(String contentDescription) {
		this.contentDescription = contentDescription;
	}

	public String getCourseVideos() {
		return courseVideos;
	}

	public void setCourseVideos(String courseVideos) {
		this.courseVideos = courseVideos;
	}

	public Courses getCourse() {
		return course;
	}

	public void setCourse(Courses course) {
		this.course = course;
	}

	public Trainer getTrainer() {
		return trainer;
	}

	public void setTrainer(Trainer trainer) {
		this.trainer = trainer;
	}
    
    
}
