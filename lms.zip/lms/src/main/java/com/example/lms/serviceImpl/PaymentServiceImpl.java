package com.example.lms.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.lms.exception.IdMismatchException;
import com.example.lms.model.Payment;
import com.example.lms.repository.PaymentRepository;
import com.example.lms.service.PaymentService;

@Service
public class PaymentServiceImpl implements PaymentService {
	
	@Autowired
	public PaymentRepository paymentRepository;

	@Override
	public Payment addPayment(Payment payment, long studentId, long courseId) throws IdMismatchException, Exception {
		// TODO Auto-generated method stub
		return paymentRepository.save(payment);
	}

	@Override
	public List<Payment> getAllPayments() {
		// TODO Auto-generated method stub
		return paymentRepository.findAll();
	}

	@Override
	public Payment getPaymentById(long paymentId) {
		// TODO Auto-generated method stub
		return paymentRepository.findById(paymentId).orElseThrow();
	}
	
}
