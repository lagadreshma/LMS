package com.example.lms.service;

import java.util.List;

import com.example.lms.exception.IdMismatchException;
import com.example.lms.model.Payment;

public interface PaymentService {
	
	Payment addPayment(Payment payment,long studentId,long courseId) throws IdMismatchException, Exception;

	List<Payment> getAllPayments();

	Payment getPaymentById(long paymentId);

}
