package com.example.lms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.lms.exception.CourseNotValidException;
import com.example.lms.model.CourseContent;
import com.example.lms.service.CourseContentService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/lms_course_content")
public class CourseContentController {
	
	@Autowired
	private CourseContentService courseContentService;
	
	@PostMapping("/addCourseContent")
	public ResponseEntity<CourseContent> addCourseContent(@PathVariable("adminId") long adminId, @RequestBody CourseContent courseContent) throws CourseNotValidException{
		System.out.println("Course Added Succesfull "+ courseContent);
		return new ResponseEntity<CourseContent>(courseContentService.addCourseContent(courseContent),HttpStatus.CREATED);
	}
	
	@GetMapping("/courseContents")
	public List<CourseContent> getAllCourseContent(){
		
		return courseContentService.getAllCourseContent();
	}
	
	@GetMapping("/courseContents/{courseConentId}")
	public ResponseEntity<CourseContent> getCourseContentById(@PathVariable("courseContentId") long courseContentId){
		
		return new ResponseEntity<CourseContent>(courseContentService.getCourseContentById(courseContentId), HttpStatus.OK);
	}
	
	  // Endpoint to delete appointment by ID
    @DeleteMapping("/courseContents/{courseContentId}")
    public ResponseEntity<String> deleteCourseContentById(@PathVariable("courseContentId") long courseContentId) {
        if (courseContentService.deleteCourseContentById(courseContentId)) {
            return new ResponseEntity<>("Course Content deleted successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Course Content not found or unable to delete", HttpStatus.NOT_FOUND);
        }
    }
	
}