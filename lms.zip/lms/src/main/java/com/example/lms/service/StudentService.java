package com.example.lms.service;

import java.util.List;

import com.example.lms.model.Student;

public interface StudentService {
	
	Student saveStudent(Student student);
	
	Student loginStudent(Student student);
	
	List<Student> getAllStudents();
	
	Student getStudentById(Student student, Long studentId);
	
	void deleteStudent(Student student, Long studentId);
	
	Student updateStudent(Student student, Long studentId);

}
