package com.example.lms.exception;

public class CourseNotValidException extends RuntimeException{
	
	public CourseNotValidException(String msg) {
		super(msg);
	}

}
