package com.example.lms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.lms.model.Student;
import com.example.lms.service.StudentService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/lms_student/")
public class StudentController {
	
	@Autowired
    private StudentService studentService;
	
	@PostMapping("/registerStudent")
    public ResponseEntity<Student> saveStudent(@RequestBody Student student) {
        System.out.println("Student Registration Successful." + student);
        return new ResponseEntity<>(studentService.saveStudent(student), HttpStatus.CREATED);
    }

    @GetMapping("/students")
    public List<Student> getAllStudents() {
        return studentService.getAllStudents();
    }

    @GetMapping("/students/{studentId}")
    public ResponseEntity<Student> getStudentById(@PathVariable("studentId") long studentId, @RequestBody Student student) {
        return new ResponseEntity<>(studentService.getStudentById(student, studentId), HttpStatus.OK);
    }

    @PutMapping("/students/{studentId}")
    public ResponseEntity<Student> updateStudent(@PathVariable("studentId") long studentId, @RequestBody Student student) {
        return new ResponseEntity<>(studentService.updateStudent(student, studentId), HttpStatus.OK);
    }

    @DeleteMapping("/students/{studentId}")
    public ResponseEntity<Boolean> deleteStudent(@PathVariable("studentId") long studentId, @RequestBody Student student) {
        studentService.deleteStudent(student, studentId);
        return new ResponseEntity<>(true, HttpStatus.OK);
    }

}
