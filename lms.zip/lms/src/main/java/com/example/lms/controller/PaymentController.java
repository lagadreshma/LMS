package com.example.lms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.lms.model.Payment;
import com.example.lms.service.PaymentService;

import lombok.AllArgsConstructor;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/lms_payment/")
@AllArgsConstructor
public class PaymentController {

	@Autowired 
	private PaymentService paymentService; 
	
	@PostMapping("/payment/{courseId}/{studentId}")
	public ResponseEntity<Payment> addPayment(@RequestBody Payment payment,@PathVariable("courseId") long courseId,
		 @PathVariable("studentId") long studentId) throws Exception {

		return new ResponseEntity<Payment>(paymentService.addPayment(payment, courseId, studentId),HttpStatus.CREATED);
	}
	
	@GetMapping("/payment")
	public List<Payment> getAllPayments(){
		return paymentService.getAllPayments();
	}
	
	@GetMapping("/payment/{paymentId}")
	public ResponseEntity<Payment> getPaymentById(@PathVariable("paymentId") long paymentId){
		
		return new ResponseEntity<Payment>(paymentService.getPaymentById(paymentId),HttpStatus.OK);
	}
	
}
