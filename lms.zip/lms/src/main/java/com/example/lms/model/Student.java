package com.example.lms.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Builder;

@Entity
@Table(name = "student_table")
@Builder
@SequenceGenerator(name = "student", sequenceName = "student_gen", initialValue = 2000)
public class Student {
    
    @Id
    @Column(name = "student_id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "student")
    private long studentId;
    
    @Column(name = "student_name")
    private String studentName;
    
    @Column(name = "student_age")
    private String studentAge;
    
    @Column(name = "student_email")
    private String studentEmail;
    
    @Column(name = "student_password")
    private String studentPassword;
    
    @Column(name = "student_mobile")
    private String studentMobile;
    
    @Column(name = "student_address")
    private String studentAddress;
    
    public Student() {}
    
    public Student(String studentName, String studentAge, String studentEmail, String studentPassword,
                   String studentMobile, String studentAddress) {
        super();
        this.studentName = studentName;
        this.studentAge = studentAge;
        this.studentEmail = studentEmail;
        this.studentPassword = studentPassword;
        this.studentMobile = studentMobile;
        this.studentAddress = studentAddress;
    }

    public long getStudentId() {
        return studentId;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentAge() {
        return studentAge;
    }

    public void setStudentAge(String studentAge) {
        this.studentAge = studentAge;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }

    public String getStudentPassword() {
        return studentPassword;
    }

    public void setStudentPassword(String studentPassword) {
        this.studentPassword = studentPassword;
    }

    public String getStudentMobile() {
        return studentMobile;
    }

    public void setStudentMobile(String studentMobile) {
        this.studentMobile = studentMobile;
    }

    public String getStudentAddress() {
        return studentAddress;
    }

    public void setStudentAddress(String studentAddress) {
        this.studentAddress = studentAddress;
    }

    @Override
    public String toString() {
        return "Student [studentId=" + studentId + ", studentName=" + studentName + ", studentAge=" + studentAge
                + ", studentEmail=" + studentEmail + ", studentPassword=" + studentPassword + ", studentMobile="
                + studentMobile + ", studentAddress=" + studentAddress + "]";
    }
}
