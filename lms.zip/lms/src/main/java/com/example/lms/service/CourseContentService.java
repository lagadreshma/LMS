package com.example.lms.service;

import java.util.List;

import com.example.lms.model.CourseContent;

public interface CourseContentService {
	
    CourseContent addCourseContent(CourseContent courseContent);
	
	List<CourseContent> getAllCourseContent();
	
	CourseContent getCourseContentById(long courseContentId);
	
	boolean deleteCourseContentById(long courseContentId);
	
	CourseContent updateCourseContent(CourseContent courseContent, long courseContentId);

}
