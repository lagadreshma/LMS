package com.example.lms.service;

import java.util.List;

import com.example.lms.model.Trainer;

public interface TrainerService {
	
	Trainer saveTrainer(Trainer trainer);
	
	Trainer loginTrainer(Trainer trainer);
	
	List<Trainer> getAllTrainer();
	
	Trainer getTrainerById(Trainer trainer, Long trainerId);
	
	void deleteTrainer(Trainer trainer, Long trainerId);
	
	Trainer updateTrainer(Trainer trainer, Long trainerId);
	

}
