package com.example.lms.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.lms.model.Trainer;
import com.example.lms.repository.TrainerRepository;
import com.example.lms.service.TrainerService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class TrainerServiceImpl implements TrainerService{
	
	@Autowired
	public TrainerRepository trainerRepository;

	@Override
	public Trainer saveTrainer(Trainer trainer) {
		// TODO Auto-generated method stub
		return trainerRepository.save(trainer);
	}

	@Override
	public Trainer loginTrainer(Trainer trainer) {
	    String email = trainer.getTrainerEmail();
	    String password = trainer.getTrainerPassword();
	    
	    return trainerRepository.findByTrainerEmailAndTrainerPassword(email, password)
	            .orElseThrow(() -> new RuntimeException("Trainer not found with email: " + email));
	}


	@Override
	public List<Trainer> getAllTrainer() {
		// TODO Auto-generated method stub
		return trainerRepository.findAll();
	}

	@Override
	public Trainer getTrainerById(Trainer trainer, Long trainerId) {
		// TODO Auto-generated method stub
		return trainerRepository.findById(trainerId).orElseThrow();
	}

	@Override
	public void deleteTrainer(Trainer trainer, Long trainerId) {
		// TODO Auto-generated method stub
		trainerRepository.findById(trainerId).orElseThrow();
		trainerRepository.deleteById(trainerId);
	}

	@Override
	public Trainer updateTrainer(Trainer trainer, Long trainerId) {
		// TODO Auto-generated method stub
		
		Trainer existingTrainer = trainerRepository.findById(trainerId).orElseThrow();
		
		existingTrainer.setTrainerName(trainer.getTrainerName());
		existingTrainer.setTrainerEmail(trainer.getTrainerEmail());
		existingTrainer.setTrainerPassword(trainer.getTrainerPassword());
		existingTrainer.setTrainerMobile(trainer.getTrainerMobile());
		existingTrainer.setTrainerAddress(trainer.getTrainerAddress());
		
		trainerRepository.save(existingTrainer);
		
		return existingTrainer;
	}

}
