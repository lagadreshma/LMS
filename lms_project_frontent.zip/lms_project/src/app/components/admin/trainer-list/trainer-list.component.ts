import { Component, OnInit } from '@angular/core';
import { TrainerService } from '../../../trainer.service';
import { Trainer } from '../../../trainer';
import { Router } from '@angular/router';

@Component({
  selector: 'app-trainer-list',
  templateUrl: './trainer-list.component.html',
  styleUrl: './trainer-list.component.css'
})
export class TrainerListComponent implements OnInit {
  trainers!: Trainer[];
  trainer: Trainer = new Trainer();
  constructor(private trainerService: TrainerService, private router : Router){ }


  ngOnInit(): void {
    this.getTrainers();
  }

  private getTrainers(){
    this.trainerService.getTrainerList().subscribe(data => {
      this.trainers = data;
    });
  }

  trainerDetails(id : number){
    this.router.navigate(['trainer-details', id]);
  }

  updateTrainer(id : number, trainer: Trainer ){
    this.router.navigate(['/admin/update-trainer-details', id]);
  }

  deleteTrainer(id : number){
    this.trainerService.deleteTrainer(id).subscribe(data => {
      console.log(data);
      this.getTrainers();
    })
  }

  addTrainer() {
    this.router.navigate(['/admin/admin-add-trainer']);
  }

}
