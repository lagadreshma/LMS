import { Component, OnInit } from '@angular/core';
import { CourseService } from '../../../course.service';
import { Courses } from '../../../courses';
import { Router } from '@angular/router';

@Component({
  selector: 'app-courses-list',
  templateUrl: './courses-list.component.html',
  styleUrl: './courses-list.component.css'
})
export class CoursesListComponent implements OnInit {
  courses: Courses[] = [];

  constructor(private courseService: CourseService, private router: Router) {}

  ngOnInit(): void {
    this.getCourses();
  }

  private getCourses() {
    this.courseService.getCourseList().subscribe(data => {
      this.courses = data;
    });
  }

  addCourse() {
    this.router.navigate(['/admin/admin-add-courses']);
  }

  updateCourse(courseId: number) {
    this.router.navigate(['/admin/update-course-details', courseId]);
  }

  deleteCourse(courseId: number) {
    this.courseService.deleteCourse(courseId).subscribe(() => {
      this.getCourses(); // Refresh the list
    });
  }

  courseDetails(courseId: number) {
    this.router.navigate(['/admin/course-details', courseId]);
  }
}

