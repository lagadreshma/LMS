import { Component, OnInit } from '@angular/core';
import { Trainer } from '../../../trainer';
import { TrainerService } from '../../../trainer.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-update-trainer-details',
  templateUrl: './update-trainer-details.component.html',
  styleUrl: './update-trainer-details.component.css'
})
export class UpdateTrainerDetailsComponent implements OnInit {
  id!: number;
  trainer: Trainer = new Trainer();

  constructor(
    private trainerService: TrainerService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.trainerService.getTrainerById(this.id).subscribe(
      data => {
        this.trainer = data;
      },
      error => console.log(error)
    );
  }

  onSubmit() {
    this.trainerService.updateTrainer(this.id, this.trainer).subscribe(
      data => {
        this.router.navigate(['/admin/trainer-list']);
      },
      error => console.log(error)
    );
  }
}
