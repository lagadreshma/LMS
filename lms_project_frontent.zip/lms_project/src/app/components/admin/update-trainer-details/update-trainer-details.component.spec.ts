import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateTrainerDetailsComponent } from './update-trainer-details.component';

describe('UpdateTrainerDetailsComponent', () => {
  let component: UpdateTrainerDetailsComponent;
  let fixture: ComponentFixture<UpdateTrainerDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UpdateTrainerDetailsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateTrainerDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
