import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrl: './admin-login.component.css'
})
export class AdminLoginComponent {

  adminEmail: string = '';
  adminPassword: string = '';

  constructor(private http: HttpClient, private router: Router) {}

  onSubmit() {
    const loginPayload = { adminEmail: this.adminEmail, adminPassword: this.adminPassword };

    this.http.post('http://localhost:8080/api/lms/admin_login', loginPayload)
      .subscribe(response => {
        alert('Login successful');
        this.router.navigate(['/admin/admin-home']); // Redirect to the desired route after successful login
      }, error => {
        alert('Invalid credentials');
      });
  }

}
