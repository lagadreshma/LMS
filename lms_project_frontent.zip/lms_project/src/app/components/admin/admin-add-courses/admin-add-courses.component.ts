import { Component } from '@angular/core';
import { Courses } from '../../../courses';
import { CourseService } from '../../../course.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-add-courses',
  templateUrl: './admin-add-courses.component.html',
  styleUrl: './admin-add-courses.component.css'
})
export class AdminAddCoursesComponent {

  course: Courses = new Courses();
  adminId: number = 1; // Variable to store adminId

  constructor(
    private courseService: CourseService,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Fetch the adminId from localStorage or any other storage method
    // const storedAdminId = localStorage.getItem('adminId');
    // if (storedAdminId) {
    //   this.adminId = +storedAdminId; // Convert to number using +
    // }
  }

  onSubmit() {
    this.course.adminId = this.adminId; // Assign the adminId to the course
    this.courseService.createCourse(this.course).subscribe(
      data => {
        this.router.navigate(['/admin/courses-list']);
      },
      error => console.log(error)
    );
  }
}
