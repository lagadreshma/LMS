import { Component, OnInit } from '@angular/core';
import { Courses } from '../../../courses';
import { CourseService } from '../../../course.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-update-course-details',
  templateUrl: './update-course-details.component.html',
  styleUrl: './update-course-details.component.css'
})
export class UpdateCourseDetailsComponent implements OnInit {

  course: Courses = new Courses();
  courseId!: number;

  constructor(
    private courseService: CourseService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.courseId = this.route.snapshot.params['id'];
    this.courseService.getCourseById(this.courseId).subscribe(
      data => {
        this.course = data;
      },
      error => console.log(error)
    );
  }

  onSubmit() {
    this.courseService.updateCourse(this.courseId, this.course).subscribe(
      data => {
        this.router.navigate(['/admin/courses-list']);
      },
      error => console.log(error)
    );
  }

}
