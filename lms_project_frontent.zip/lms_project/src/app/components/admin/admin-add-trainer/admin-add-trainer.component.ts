import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TrainerService } from '../../../trainer.service';
import { Trainer } from '../../../trainer';

@Component({
  selector: 'app-admin-add-trainer',
  templateUrl: './admin-add-trainer.component.html',
  styleUrl: './admin-add-trainer.component.css'
})
export class AdminAddTrainerComponent implements OnInit {

  trainer: Trainer = new Trainer();

  constructor(private trainerService: TrainerService, private router: Router) { }

  ngOnInit(): void { }

  saveTrainer() {
    this.trainerService.createTrainer(this.trainer).subscribe(
      data => {
        console.log(data);
        this.goToTrainerList();
      },
      error => console.log(error)
    );
  }

  goToTrainerList() {
    this.router.navigate(['/admin/trainer-list']);
  }

  onSubmit() {
    console.log(this.trainer);
    this.saveTrainer();
  }
}
