import { Component, OnInit } from '@angular/core';
import { Student } from '../../../student';
import { StudentService } from '../../../student.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-add-student',
  templateUrl: './admin-add-student.component.html',
  styleUrl: './admin-add-student.component.css'
})
export class AdminAddStudentComponent implements OnInit {
  student: Student = new Student();

  constructor(private studentService: StudentService, private router: Router) { }

  ngOnInit(): void { }

  saveStudent() {
    this.studentService.createStudent(this.student).subscribe(
      data => {
        console.log(data);
        this.goToStudentList();
      },
      error => console.log(error)
    );
  }

  goToStudentList() {
    this.router.navigate(['/admin/student-list']);
  }

  onSubmit() {
    console.log(this.student);
    this.saveStudent();
  }
}

