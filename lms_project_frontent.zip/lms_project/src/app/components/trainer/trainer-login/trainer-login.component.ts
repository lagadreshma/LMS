import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-trainer-login',
  templateUrl: './trainer-login.component.html',
  styleUrl: './trainer-login.component.css'
})
export class TrainerLoginComponent {

  trainerEmail: string = '';
  trainerPassword: string = '';

  constructor(private http: HttpClient, private router: Router) {}

  onSubmit() {
    const loginPayload = { trainerEmail: this.trainerEmail, trainerPassword: this.trainerPassword };

    this.http.post('http://localhost:8080/api/lms/trainer_login', loginPayload)
      .subscribe(response => {
        alert('Login successful');
        this.router.navigate(['/trainer/trainer-home']); // Redirect to the desired route after successful login
      }, error => {
        alert('Invalid credentials');
      });
  }

}

