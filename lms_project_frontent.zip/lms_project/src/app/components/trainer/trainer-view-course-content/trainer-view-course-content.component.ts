import { Component } from '@angular/core';

@Component({
  selector: 'app-trainer-view-course-content',
  templateUrl: './trainer-view-course-content.component.html',
  styleUrl: './trainer-view-course-content.component.css'
})
export class TrainerViewCourseContentComponent {

}
