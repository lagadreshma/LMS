import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainerViewCourseContentComponent } from './trainer-view-course-content.component';

describe('TrainerViewCourseContentComponent', () => {
  let component: TrainerViewCourseContentComponent;
  let fixture: ComponentFixture<TrainerViewCourseContentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TrainerViewCourseContentComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrainerViewCourseContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
