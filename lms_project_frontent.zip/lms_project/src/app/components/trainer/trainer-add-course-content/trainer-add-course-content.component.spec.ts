import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainerAddCourseContentComponent } from './trainer-add-course-content.component';

describe('TrainerAddCourseContentComponent', () => {
  let component: TrainerAddCourseContentComponent;
  let fixture: ComponentFixture<TrainerAddCourseContentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TrainerAddCourseContentComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrainerAddCourseContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
