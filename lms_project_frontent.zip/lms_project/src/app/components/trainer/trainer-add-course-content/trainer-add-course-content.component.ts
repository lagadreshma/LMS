import { Component } from '@angular/core';

@Component({
  selector: 'app-trainer-add-course-content',
  templateUrl: './trainer-add-course-content.component.html',
  styleUrl: './trainer-add-course-content.component.css'
})
export class TrainerAddCourseContentComponent {

}
