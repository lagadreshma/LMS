import { Component } from '@angular/core';

@Component({
  selector: 'app-trainer-home',
  templateUrl: './trainer-home.component.html',
  styleUrl: './trainer-home.component.css'
})
export class TrainerHomeComponent {

}
