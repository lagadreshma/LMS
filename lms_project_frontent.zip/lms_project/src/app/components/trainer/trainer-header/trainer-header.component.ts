import { Component, OnInit } from '@angular/core';
import { NavigationStart, Router } from '@angular/router';
import { filter } from 'rxjs';

@Component({
  selector: 'app-trainer-header',
  templateUrl: './trainer-header.component.html',
  styleUrl: './trainer-header.component.css'
})
export class TrainerHeaderComponent implements OnInit{

  url: string = "/";

  constructor(private route: Router){  }

  ngOnInit(): void {
    this.route.events.pipe(
     filter(event => event instanceof NavigationStart)
    ).subscribe((event: any) => {
      this.url = event?.url;
    });
  }


  gotourl(route: string) {
    const trainerName = localStorage.getItem('trainerName') || 'Radhika'; // Replace with dynamic fetching
    if (route.includes('trainer-courses')) {
      this.route.navigate([`trainer/trainer-courses`, trainerName]); // Updated route
    } else {
      this.route.navigate([route]);
    }
  }
  

 logout() {
  // Clear the authentication tokens or any other stored data
  localStorage.clear();
  // Navigate to the login or home page
  this.route.navigate(['/home']);
}



}
