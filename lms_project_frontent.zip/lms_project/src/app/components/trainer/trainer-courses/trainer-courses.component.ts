import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Courses } from '../../../courses';
import { CourseService } from '../../../course.service';

@Component({
  selector: 'app-trainer-courses',
  templateUrl: './trainer-courses.component.html',
  styleUrl: './trainer-courses.component.css'
})
export class TrainerCoursesComponent implements OnInit{

  courses: Courses[] = [];

  constructor(private courseService: CourseService, private router: Router) {}

  ngOnInit(): void {
    this.getCourses();
  }

  private getCourses() {
    this.courseService.getCourseList().subscribe(data => {
      this.courses = data;
    });
  }


  addCourseContent(courseId: number) {
    this.router.navigate(['/trainer', courseId]);
  }

  deleteCourse(courseId: number) {
    this.courseService.deleteCourse(courseId).subscribe(() => {
      this.getCourses(); // Refresh the list
    });
  }

  courseDetails(courseId: number) {
    this.router.navigate(['/admin/course-details', courseId]);
  }

 
}
