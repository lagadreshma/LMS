import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-student-login',
  templateUrl: './student-login.component.html',
  styleUrl: './student-login.component.css'
})
export class StudentLoginComponent {
  studentEmail: string = '';
  studentPassword: string = '';

  constructor(private http: HttpClient, private router: Router) {}

  onSubmit() {
    const loginPayload = { studentEmail: this.studentEmail, studentPassword: this.studentPassword };

    this.http.post('http://localhost:8080/api/lms/student_login', loginPayload)
      .subscribe(response => {
        alert('Login successful');
        this.router.navigate(['/student/student-details']); // Redirect to the desired route after successful login
      }, error => {
        alert('Invalid credentials');
      });
  }
}
