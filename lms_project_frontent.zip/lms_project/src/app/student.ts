export class Student {

    studentId!:number;
    studentName!:string;
    studentAge!: number;
    studentEmail!: string;
    studentPassword!: string;
    studentMobile!: number;
    studentAddress!:string;


}
