import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { StudentSignupComponent } from './components/student/student-signup/student-signup.component';
import { StudentLoginComponent } from './components/student/student-login/student-login.component';
import { StudentDetailsComponent } from './components/student/student-details/student-details.component';
import { AppHeaderComponent } from './components/app-header/app-header.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AdminHomeComponent } from './components/admin/admin-home/admin-home.component';
import { AdminLoginComponent } from './components/admin/admin-login/admin-login.component';
import { AdminHeaderComponent } from './components/admin/admin-header/admin-header.component';
import { AdminAddCoursesComponent } from './components/admin/admin-add-courses/admin-add-courses.component';
import { AdminAddStudentComponent } from './components/admin/admin-add-student/admin-add-student.component';
import { AdminAddTrainerComponent } from './components/admin/admin-add-trainer/admin-add-trainer.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { CoursesComponent } from './components/courses/courses.component';
import { TrainerHeaderComponent } from './components/trainer/trainer-header/trainer-header.component';
import { TrainerHomeComponent } from './components/trainer/trainer-home/trainer-home.component';
import { TrainerAddCourseContentComponent } from './components/trainer/trainer-add-course-content/trainer-add-course-content.component';
import { TrainerLoginComponent } from './components/trainer/trainer-login/trainer-login.component';
import { TrainerViewCourseContentComponent } from './components/trainer/trainer-view-course-content/trainer-view-course-content.component';
import { StudentListComponent } from './components/admin/student-list/student-list.component';
import { TrainerListComponent } from './components/admin/trainer-list/trainer-list.component';
import { CoursesListComponent } from './components/admin/courses-list/courses-list.component';
import { UpdateStudentDetailsComponent } from './components/admin/update-student-details/update-student-details.component';
import { UpdateTrainerDetailsComponent } from './components/admin/update-trainer-details/update-trainer-details.component';
import { UpdateCourseDetailsComponent } from './components/admin/update-course-details/update-course-details.component';
import { TrainerCoursesComponent } from './components/trainer/trainer-courses/trainer-courses.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    StudentSignupComponent,
    StudentLoginComponent,
    StudentDetailsComponent,
    AppHeaderComponent,
    AdminHomeComponent,
    AdminLoginComponent,
    AdminHeaderComponent,
    AdminAddCoursesComponent,
    AdminAddStudentComponent,
    AdminAddTrainerComponent,
    AboutUsComponent,
    ContactUsComponent,
    CoursesComponent,
    TrainerHeaderComponent,
    TrainerHomeComponent,
    TrainerAddCourseContentComponent,
    TrainerLoginComponent,
    TrainerViewCourseContentComponent,
    StudentListComponent,
    TrainerListComponent,
    CoursesListComponent,
    UpdateStudentDetailsComponent,
    UpdateTrainerDetailsComponent,
    UpdateCourseDetailsComponent,
    TrainerCoursesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
