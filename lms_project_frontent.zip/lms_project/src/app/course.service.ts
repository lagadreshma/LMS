import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Courses } from './courses';

@Injectable({
  providedIn: 'root'
})
export class CourseService {

  private baseURL = "http://localhost:8080/api/lms/courses";

  constructor(private httpClient: HttpClient) { }

  getCourseList(): Observable<Courses[]> {
    return this.httpClient.get<Courses[]>(`${this.baseURL}`);
  }

  createCourse(course: Courses): Observable<Object> {
    return this.httpClient.post(`${this.baseURL}`, course);
  }

  getCourseById(id: number): Observable<Courses> {
    return this.httpClient.get<Courses>(`${this.baseURL}/${id}`);
  }

  updateCourse(id: number, course: Courses): Observable<Object> {
    return this.httpClient.put(`${this.baseURL}/${id}`, course);
  }

  deleteCourse(id: number): Observable<Object> {
    return this.httpClient.delete(`${this.baseURL}/${id}`);
  }


  // Method to get courses by trainer name
  getCoursesByTrainer(trainerName: string): Observable<Courses[]> {
    return this.httpClient.get<Courses[]>(`${this.baseURL}/trainer/${trainerName}`);
  }


}
