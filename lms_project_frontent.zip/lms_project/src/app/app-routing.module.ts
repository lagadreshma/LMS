import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { StudentSignupComponent } from './components/student/student-signup/student-signup.component';
import { StudentLoginComponent } from './components/student/student-login/student-login.component';
import { StudentDetailsComponent } from './components/student/student-details/student-details.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { CoursesComponent } from './components/courses/courses.component';
import { AdminLoginComponent } from './components/admin/admin-login/admin-login.component';
import { AdminAddTrainerComponent } from './components/admin/admin-add-trainer/admin-add-trainer.component';
import { AdminAddStudentComponent } from './components/admin/admin-add-student/admin-add-student.component';
import { AdminAddCoursesComponent } from './components/admin/admin-add-courses/admin-add-courses.component';
import { AdminHomeComponent } from './components/admin/admin-home/admin-home.component';
import { TrainerLoginComponent } from './components/trainer/trainer-login/trainer-login.component';
import { TrainerHomeComponent } from './components/trainer/trainer-home/trainer-home.component';
import { TrainerAddCourseContentComponent } from './components/trainer/trainer-add-course-content/trainer-add-course-content.component';
import { TrainerViewCourseContentComponent } from './components/trainer/trainer-view-course-content/trainer-view-course-content.component';
import { StudentListComponent } from './components/admin/student-list/student-list.component';
import { TrainerListComponent } from './components/admin/trainer-list/trainer-list.component';
import { CoursesListComponent } from './components/admin/courses-list/courses-list.component';
import { UpdateStudentDetailsComponent } from './components/admin/update-student-details/update-student-details.component';
import { UpdateTrainerDetailsComponent } from './components/admin/update-trainer-details/update-trainer-details.component';
import { UpdateCourseDetailsComponent } from './components/admin/update-course-details/update-course-details.component';
import { TrainerCoursesComponent } from './components/trainer/trainer-courses/trainer-courses.component';

const routes: Routes = [
  {path: 'home', component: HomeComponent},
  {path: 'about-us', component: AboutUsComponent},
  {path: 'contact-us', component: ContactUsComponent},
  {path: 'courses', component: CoursesComponent},
  {path: 'student', children:[
    {path: 'student-signup', component: StudentSignupComponent},
    {path: 'student-login', component: StudentLoginComponent},
    {path: 'student-details', component: StudentDetailsComponent}
  ]},
  {path: 'admin', children: [
    {path: 'admin-login', component: AdminLoginComponent},
    {path: 'admin-add-trainer', component: AdminAddTrainerComponent},
    {path: 'admin-add-student', component: AdminAddStudentComponent},
    {path: 'admin-add-courses', component: AdminAddCoursesComponent},
    {path: 'admin-home', component: AdminHomeComponent},
    {path: 'student-list', component: StudentListComponent},
    {path: 'trainer-list', component: TrainerListComponent},
    {path: 'courses-list', component: CoursesListComponent},
    {path: 'update-student-details/:id', component: UpdateStudentDetailsComponent},
    {path: 'update-trainer-details/:id', component: UpdateTrainerDetailsComponent},
    {path: 'update-course-details/:id', component: UpdateCourseDetailsComponent}
  ]},
  {path: 'trainer', children: [
    {path: 'trainer-login', component: TrainerLoginComponent},
    {path: 'trainer-home', component: TrainerHomeComponent},
    {path: 'trainer-add-course-content', component: TrainerAddCourseContentComponent},
    {path: 'trainer-view-course-content', component: TrainerViewCourseContentComponent},
    {path: 'trainer-courses/:trainerName', component: TrainerCoursesComponent}
  ]}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
