export class CourseContent {

    contentId!: number;
    contentName!: string;
    contentDescription!: string;
    courseId!: number;
    trainerId!: string;

}
