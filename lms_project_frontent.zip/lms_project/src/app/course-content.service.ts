import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CourseContent } from './coursecontent';

@Injectable({
  providedIn: 'root'
})
export class CourseContentService {

  private baseURL = "http://localhost:8080/api/lms/course_content";

  constructor(private httpClient: HttpClient) { }

  getAllCourseContent(): Observable<CourseContent[]> {
    return this.httpClient.get<CourseContent[]>(`${this.baseURL}`);
  }

  addCourseContent(courseContent: CourseContent): Observable<Object> {
    return this.httpClient.post(`${this.baseURL}`, courseContent);
  }

  getCourseContentById(id: number): Observable<CourseContent> {
    return this.httpClient.get<CourseContent>(`${this.baseURL}/${id}`);
  }

  updateCourseContent(id: number, courseContent: CourseContent): Observable<Object> {
    return this.httpClient.put(`${this.baseURL}/${id}`, courseContent);
  }

  deleteCourseContent(id: number): Observable<Object> {
    return this.httpClient.delete(`${this.baseURL}/${id}`);
  }
  
}
