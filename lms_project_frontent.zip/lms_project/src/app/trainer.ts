export class Trainer {

    trainerId!: number;
    trainerName!: string;
    trainerEmail!: string;
    trainerPassword!: string;
    trainerMobile!: number;
    trainerAddress!: string;

}
