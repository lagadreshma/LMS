export class Admin {

    adminId!: number;
    adminName!: string;
    adminEmail!: string;
    adminPassword!: string;
    adminMobile!: number;
    adminAddress!: string;

}
