import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Admin } from './admin';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  private baseURL = "http://localhost:8080/api/lms/admin";

  constructor(private httpClient: HttpClient) { }


  getAdminById(id: number): Observable<Admin> {
    return this.httpClient.get<Admin>(`${this.baseURL}/${id}`);
  }
  
}
