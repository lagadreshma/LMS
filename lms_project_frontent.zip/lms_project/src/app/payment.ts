export class Payment {

    paymentId!: number;
    paymentStatus!: string;
    paymentDate!: string;
    courseId!: number;
    studentId!: number;
    coursePrice!: number;

}
