export class Courses {

    courseId!: number;
    courseName!: string;
    courseDescription!: string;
    trainerName!: string;
    coursePrice!: number;
    courseRating!: number;
    adminId!: number;

}
