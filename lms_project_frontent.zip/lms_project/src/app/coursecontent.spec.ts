import { Coursecontent } from './coursecontent';

describe('Coursecontent', () => {
  it('should create an instance', () => {
    expect(new Coursecontent()).toBeTruthy();
  });
});
